import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

// Enum for user types
enum UserType {
    ADMIN, USER
}

// User class
class User {
    private String username;
    private String password;
    private UserType type;

    public User(String username, String password, UserType type) {
        this.username = username;
        this.password = password;
        this.type = type;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public UserType getType() {
        return type;
    }
}


