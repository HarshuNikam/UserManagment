import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UserManagementSystem {
    private Map<String, User> users;

    public UserManagementSystem() {
        this.users = new HashMap<>();
    }

 
    public void addUser(String username, String password, UserType type) {
        users.put(username, new User(username, password, type));
    }

  
    public boolean authenticateUser(String username, String password) {
        User user = users.get(username);
        return user != null && user.getPassword().equals(password);
    }

    
    public UserType getUserType(String username) {
        User user = users.get(username);
        return user != null ? user.getType() : null;
    }

    public static void main(String[] args) {
        UserManagementSystem system = new UserManagementSystem();
        system.addUser("admin", "admin123", UserType.ADMIN);
        system.addUser("user", "user123", UserType.USER);

        Scanner scanner = new Scanner(System.in);

      
        System.out.println("Login Page");
        System.out.print("Username: ");
        String username = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();

        if (system.authenticateUser(username, password)) {
            System.out.println("Login successful!");
            UserType userType = system.getUserType(username);
            System.out.println("User Type: " + userType);
        
        } else {
            System.out.println("Invalid username or password!");
        }

      
        System.out.println("\nSignup Page");
        System.out.print("Username: ");
        String newUsername = scanner.nextLine();
        System.out.print("Password: ");
        String newPassword = scanner.nextLine();
        if (system.users.containsKey(newUsername)) {
            System.out.println("Username already exists!");
        } else {
          
            system.addUser(newUsername, newPassword, UserType.USER);
            System.out.println("Signup successful!");
        }

        scanner.close();
    }
}